module.exports = {
	secret: 'btpn-secret-key',
}
