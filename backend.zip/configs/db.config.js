module.exports = {
	url: 'mongodb+srv://akbarpathur:sRbWj!LW4q$Abz$@cluster0.xrlzy.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',
}
